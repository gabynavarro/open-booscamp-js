//Crea un nuevo archivo JS que contenga una lista con los siguientes elementos:
//- Tu nombre (string)
//- Tu edad (number)
//- ¿Eres desarrollador? (boolean)
//- Tu fecha de nacimiento (Date)
//- Tu libro favorito (Objeto con propiedades: titulo, autor, fecha, url)
const fecha=new Date(1975,08,09);
const libro={
    titulo: "sr de los anillos",
    autor:"nose",
    fecha:new Date(1995,02,12),
    url:"https://es.wikipedia.org/wiki/El_Se%C3%B1or_de_los_Anillos"

};
const lista1=["Gabriel", 46, true, fecha, ];

